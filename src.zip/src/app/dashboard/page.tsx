"use client";
import { useEffect, useState } from "react";

type Me = {
  id: number;
  steamId: string;
  personaName: string | null;
  avatar: string | null;
  createdAt: string; // 서버 가입일
};

export default function Dashboard() {
  const [token, setToken] = useState<string | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);

  // 1) access 토큰 발급
  useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/v1/auth/steam/token", {
          method: "POST",
          credentials: "include",
        });
        if (!r.ok) throw new Error("token issue failed");
        const j = await r.json();
        if (j?.accessToken) setToken(j.accessToken);
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  // 2) 내 프로필 조회
  useEffect(() => {
    if (!token) return;
    (async () => {
      try {
        const r = await fetch("/api/v1/me", {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!r.ok) throw new Error("me fetch failed");
        setMe(await r.json());
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, [token]);

  return (
    <main className="px-6 pt-20 pb-8">
      {/* 프로필 카드 */}
      <section className="max-w-3xl">
        <div className="rounded-2xl bg-white/5 border border-white/10 p-5 flex gap-5 items-center">
          <img
            src={me?.avatar ?? "/placeholder-avatar.png"}
            alt="avatar"
            width={64}
            height={64}
            className="w-16 h-16 rounded-lg object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="flex-1">
            <div className="text-xl font-semibold">
              {me?.personaName || "(이름 없음)"}
            </div>
            <div className="text-sm text-white/70">
              SteamID: {me?.steamId ?? "-"}
            </div>
            <div className="text-xs text-white/50 mt-1">
              가입일:
              {me?.createdAt ? new Date(me.createdAt).toLocaleString() : "-"}
            </div>
          </div>

          <button
            className="px-3 py-2 text-sm rounded bg-white/10 hover:bg-white/20"
            onClick={async () => {
              if (!token) return;
              const r = await fetch("/api/v1/me", {
                headers: { Authorization: `Bearer ${token}` },
              });
              if (r.ok) setMe(await r.json());
            }}
          >
            새로고침
          </button>
        </div>
      </section>
    </main>
  );
}
